#include "MenuCilico.h"

MenuCilico::~MenuCilico()
{
}

void MenuCilico::Seleccion()
{
}
