#pragma once

#include <exception>
#include <string>
#include "VectorGenerico.h"

template<typename T>
class MatrizGenerica {
public:
    MatrizGenerica(int filas, int columnas);
    ~MatrizGenerica();

    VectorGenerico<T>& operator[](int fila);
    int getFilas();
    int getColumnas();

private:
    VectorGenerico<VectorGenerico<T>> matriz;
    int filas;
    int columnas;
};

template<typename T>
MatrizGenerica<T>::MatrizGenerica(int filas, int columnas)
    : filas(filas), columnas(columnas), matriz(filas) {
    for (int i = 0; i < filas; i++) {
        matriz.registrar(VectorGenerico<T>(columnas));
    }
}

template<typename T>
MatrizGenerica<T>::~MatrizGenerica() {
}

template<typename T>
VectorGenerico<T>& MatrizGenerica<T>::operator[](int fila) {
    if (fila < 0 || fila >= filas) {
        throw std::out_of_range("�ndice de fila fuera de rango");
    }
    return matriz[fila];
}

template<typename T>
int MatrizGenerica<T>::getFilas() {
    return filas;
}

template<typename T>
int MatrizGenerica<T>::getColumnas() {
    return columnas;
}
