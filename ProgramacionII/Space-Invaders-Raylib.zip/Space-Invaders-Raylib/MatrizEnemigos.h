#pragma once

#include "Dibujo.h"
#include "VectorGenerico.h"
#include "Alien.h"
#include "MatrizGenerica.h"

class MatrizEnemigos {
public:
    MatrizEnemigos(int filas, int columnas);
    ~MatrizEnemigos();

    void registrarAlien(int fila, int columna, Alien alien);
    Alien& obtenerAlien(int fila, int columna);

    Vector2 GetPosicionDerecha();
    Vector2 GetPosicionIzquierda();
    Vector2 GetPosicionAbajo();
    Vector2 GetPosicionArriba();

    void setPosicionGeneral(Vector2 nuevaPosicion);
    void moverMatriz(Vector2 desplazamiento);

private:
    MatrizGenerica<Alien> matriz;
    Vector2 posicionGeneral;
};

MatrizEnemigos::MatrizEnemigos(int filas, int columnas)
    : matriz(filas, columnas), posicionGeneral({ 0, 0 }) {
}

MatrizEnemigos::~MatrizEnemigos() {
}

void MatrizEnemigos::registrarAlien(int fila, int columna, Alien alien) {
    matriz[fila].registrar(alien);
}

Alien& MatrizEnemigos::obtenerAlien(int fila, int columna) {
    return matriz[fila][columna];
}

Vector2 MatrizEnemigos::GetPosicionDerecha() {
    Vector2 posicionDerecha = { -1, -1 };
    for (int i = 0; i < matriz.getFilas(); i++) {
        for (int j = 0; j < matriz[i].getCantidadActual(); j++) {
            Alien& alien = matriz[i][j];
            if (alien.getEstaVivo()) {
                if (posicionDerecha.x == -1 || alien.GetPosicion().x > posicionDerecha.x) {
                    posicionDerecha = alien.GetPosicion();
                }
            }
        }
    }
    return posicionDerecha;
}

Vector2 MatrizEnemigos::GetPosicionIzquierda() {
    Vector2 posicionIzquierda = { -1, -1 };
    for (int i = 0; i < matriz.getFilas(); i++) {
        for (int j = 0; j < matriz[i].getCantidadActual(); j++) {
            Alien& alien = matriz[i][j];
            if (alien.getEstaVivo()) {
                if (posicionIzquierda.x == -1 || alien.GetPosicion().x < posicionIzquierda.x) {
                    posicionIzquierda = alien.GetPosicion();
                }
            }
        }
    }
    return posicionIzquierda;
}

Vector2 MatrizEnemigos::GetPosicionAbajo() {
    Vector2 posicionAbajo = { -1, -1 };
    for (int i = 0; i < matriz.getFilas(); i++) {
        for (int j = 0; j < matriz[i].getCantidadActual(); j++) {
            Alien& alien = matriz[i][j];
            if (alien.getEstaVivo()) {
                if (posicionAbajo.y == -1 || alien.GetPosicion().y > posicionAbajo.y) {
                    posicionAbajo = alien.GetPosicion();
                }
            }
        }
    }
    return posicionAbajo;
}

Vector2 MatrizEnemigos::GetPosicionArriba() {
    Vector2 posicionArriba = { -1, -1 };
    for (int i = 0; i < matriz.getFilas(); i++) {
        for (int j = 0; j < matriz[i].getCantidadActual(); j++) {
            Alien& alien = matriz[i][j];
            if (alien.getEstaVivo()) {
                if (posicionArriba.y == -1 || alien.GetPosicion().y < posicionArriba.y) {
                    posicionArriba = alien.GetPosicion();
                }
            }
        }
    }
    return posicionArriba;
}

void MatrizEnemigos::setPosicionGeneral(Vector2 nuevaPosicion) {
    Vector2 desplazamiento = { nuevaPosicion.x - posicionGeneral.x, nuevaPosicion.y - posicionGeneral.y };
    moverMatriz(desplazamiento);
    posicionGeneral = nuevaPosicion;
}

void MatrizEnemigos::moverMatriz(Vector2 desplazamiento) {
    for (int i = 0; i < matriz.getFilas(); i++) {
        for (int j = 0; j < matriz[i].getCantidadActual(); j++) {
            Alien& alien = matriz[i][j];
            Vector2 nuevaPosicion = { alien.GetPosicion().x + desplazamiento.x, alien.GetPosicion().y + desplazamiento.y };
            alien.setPosicion(nuevaPosicion);
        }
    }
}
